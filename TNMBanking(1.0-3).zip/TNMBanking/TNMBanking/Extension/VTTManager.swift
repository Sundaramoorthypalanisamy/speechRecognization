//
//  VTTManager.swift
//  TNMBanking
//
//  Created by Prabakaran on 10/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import Foundation
import AVFoundation
import Speech

typealias successBlock = (String) -> Void
typealias failedBlock = (String) -> Void

class VTTManager: NSObject {
    
    static var shared = VTTManager()
    
    let audioEngine = AVAudioEngine()
    let speechRecognizer: SFSpeechRecognizer? = SFSpeechRecognizer(locale: Locale(identifier: "en-IN"))
    var sfrequest = SFSpeechAudioBufferRecognitionRequest()
    var recognitionTask: SFSpeechRecognitionTask?
    
    var detectionTimer: Timer!
    var detectionText: String!
    
    func isRunning() -> Bool
    {
        return audioEngine.isRunning
    }
    
    func RecordAndConvertSpeechToText(success: @escaping successBlock, failed: @escaping failedBlock)
    {
        guard self.audioEngine.isRunning == false else {
            return
        }
        
        let node = audioEngine.inputNode
        let recordingFormat = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, _) in
            self.sfrequest.append(buffer)
        }
        
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            return print(error)
        }
        
        guard let myRecognizer = SFSpeechRecognizer() else {
            return
        }
        
        if !myRecognizer.isAvailable {
            print("not available right now")
            return
        }
        
        recognitionTask = speechRecognizer?.recognitionTask(with: sfrequest, resultHandler: { (result, error) in
            
//            var isFinal = false
//            if result != nil {
//                self.detectionText = result?.bestTranscription.formattedString
//                isFinal = (result?.isFinal)!
//            }
//            
//            if let timer = self.detectionTimer, timer.isValid {
//                if isFinal {
//                    success(self.detectionText!)
//                    self.detectionTimer?.invalidate()
//                }
//            } else {
//                self.detectionTimer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (timer) in
//                    //self.handleSend()
//                    isFinal = true
//                    timer.invalidate()
//                })
//            }
            
            
            if result != nil {
                let text = result?.bestTranscription.formattedString
                success(text!)
            }
            else if let error = error
            {
                print(error)
                if (self.audioEngine.isRunning){
                    self.StopRecording()
                    failed(error.localizedDescription)
                }
            }
        })
        
    }
    
    func StopRecording() {
        if (self.audioEngine.isRunning){
            let node = audioEngine.inputNode
            node.removeTap(onBus: 0)
            self.audioEngine.stop()
            self.sfrequest.endAudio()
            recognitionTask?.cancel()
        }
    }
    
    func requestSpeechAuthorization()
    {
//        SFSpeechRecognizer.requestAuthorization { authStatus in
//            OperationQueue.main.addOperation {
//                switch authStatus
//                {
//                case .authorized :
//                    self.sbutton.isEnabled = true
//                case .denied :
//                    self.sbutton.isEnabled = false
//                    self.slabel.text = "User denied access to speech recognition"
//                case .restricted :
//                    self.sbutton.isEnabled = false
//                    self.slabel.text = "Speech Recognition is restricted on this Device"
//                case .notDetermined :
//                    self.sbutton.isEnabled = false
//                    self.slabel.text = "Speech Recognition not yet authorized"
//                }
//            }
//
//        }
    }
}

class TTSManager: NSObject {
    
    static var shared = TTSManager()

    let synth = AVSpeechSynthesizer()
    var myUtterance = AVSpeechUtterance(string: "")
    
    func SpeechContent(message: String, speedRate: Float)
    {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSessionCategoryPlayback)
            try audioSession.overrideOutputAudioPort(AVAudioSessionPortOverride.speaker)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
        }
       
        myUtterance = AVSpeechUtterance(string: message)
        myUtterance.rate = Float(speedRate)
        synth.speak(myUtterance)
    }
}

class STTManager: NSObject {
    
    
    //static var shared = STTManager()

    var speechRecognizerUtility: SpeechRecognitionUtility?

    func StartSpeechToText(state: RecordingState, success: @escaping successBlock, failed: @escaping failedBlock)
    {
        if speechRecognizerUtility == nil{
            speechRecognizerUtility = SpeechRecognitionUtility(speechRecognitionAuthorizedBlock: { [weak self] in
                self?.performSpeechRecognition()
                }, stateUpdateBlock: { (currentSpeechRecognitionState) in
                    
                    switch currentSpeechRecognitionState {
                    case .authorized:
                        print("Authorized")
                    case .audioEngineStart:
                        print("Audio Engine Start")
                    case .audioEngineStop:
                        print("Audio Engine Stop")
                    case .recognitionTaskCancelled:
                        print("Recognition Task Cancelled")
                    case .speechRecognized(let recognizedString):
                        print("Recognized String \(recognizedString)")
                        success(recognizedString)
                    case .speechNotRecognized:
                        print("Speech Not Recognized")
                    case .availabilityChanged(let availability):
                        print("Availability \(availability)")
                    case .speechRecognitionStopped(let finalRecognizedString):
                        print(finalRecognizedString)
                    }
                    
            }, recordingState: state)
        } else {
            self.performSpeechRecognition()
        }
    }
    
    func StopSpeechToText()
    {
        if speechRecognizerUtility?.isAudioEngineRunning() == true {
            do {
                try speechRecognizerUtility?.toggleSpeechRecognitionActivity()
            }catch{
                
            }
        }
    }

    
    private func performSpeechRecognition() {
        do {
            try self.speechRecognizerUtility?.toggleSpeechRecognitionActivity()
        } catch SpeechRecognitionOperationError.denied {
            print("Awww")
        } catch SpeechRecognitionOperationError.notDetermined {
            print("Awww")
        } catch SpeechRecognitionOperationError.restricted {
            print("Awww")
        } catch SpeechRecognitionOperationError.audioSessionUnavailable {
            print("Awww")
        } catch SpeechRecognitionOperationError.inputNodeUnavailable {
            print("Awww")
        } catch SpeechRecognitionOperationError.invalidRecognitionRequest {
            print("Awww")
        } catch SpeechRecognitionOperationError.audioEngineUnavailable {
            print("Awww")
        } catch {
            print("Unknown Error")
        }
    }
}
