//
//  ModelManager.swift
//  TNMBanking
//
//  Created by Prabakaran on 17/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import Foundation
import UIKit


struct User {
    
    var id: Int?
    var name: String?
    var email: String?
    var accountnumber: String?
    var passcode: String?
    var balance: Int?
}

struct Statement {
    var id: Int?
    var from: String?
    var to: String?
    var amount: String?
    var date: String?
}
