//
//  DashboardViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 28/06/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController {

    var speechRecognizerUtility: SpeechRecognitionUtility?

    var userinfo: User!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var msgLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!


    @IBOutlet weak var balanceView: UIView!
    @IBOutlet weak var transferView: UIView!
    @IBOutlet weak var statementView: UIView!
    @IBOutlet weak var settingsView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Dashboard"
        
        balanceView.addCornerRadius(radious: 15)
        transferView.addCornerRadius(radious: 15)
        statementView.addCornerRadius(radious: 15)
        settingsView.addCornerRadius(radious: 15)

        let useraccno = UserDefaults.standard.value(forKey: "UserAccNum") as! String
        let userinfo = DBManager.shared.GetUserInfo(accountnumber: useraccno)
        let username = userinfo?.name
        self.nameLabel.text = "Welcome \(username!)"
        
        TTSManager.shared.SpeechContent(message: "Hello \(username!)", speedRate: 0.5)
        TTSManager.shared.SpeechContent(message: msgLabel.text!, speedRate: 0.5)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM yyyy, hh:mm a"
        let strDate: String = formatter.string(from: Date())
        dateLabel.text = strDate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    @IBAction func LogoutButtonTapped()
    {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func startListening()
    {
        if speechRecognizerUtility == nil {
            speechRecognizerUtility = SpeechRecognitionUtility(speechRecognitionAuthorizedBlock: { [weak self] in
                self?.performSpeechRecognition()
                }, stateUpdateBlock: { (currentSpeechRecognitionState) in
                    
                    self.stateChangedWithNew(state: currentSpeechRecognitionState)
                    
            }, recordingState: .oneWordAtTime)
        } else {
            self.performSpeechRecognition()
        }
    }

    
    
    
    
    private func performSpeechRecognition() {
        do {
            try self.speechRecognizerUtility?.toggleSpeechRecognitionActivity()
        } catch SpeechRecognitionOperationError.denied {
            print("Awww")
        } catch SpeechRecognitionOperationError.notDetermined {
            print("Awww")
        } catch SpeechRecognitionOperationError.restricted {
            print("Awww")
        } catch SpeechRecognitionOperationError.audioSessionUnavailable {
            print("Awww")
        } catch SpeechRecognitionOperationError.inputNodeUnavailable {
            print("Awww")
        } catch SpeechRecognitionOperationError.invalidRecognitionRequest {
            print("Awww")
        } catch SpeechRecognitionOperationError.audioEngineUnavailable {
            print("Awww")
        } catch {
            print("Unknown Error")
        }
    }
    
    private func stateChangedWithNew(state: SpeechRecognitionOperationState) {
        switch state {
        case .authorized:
            print("Authorized")
        case .audioEngineStart:
//            self.speechTextLabel.text = "Say Something...."
//            self.speechTextLabel.textColor = .green
//            self.speechButton.setTitle("Stop Speech Recognition", for: .normal)
            print("Audio Engine Start")
        case .audioEngineStop:
            print("Audio Engine Stop")
        case .recognitionTaskCancelled:
            print("Recognition Task Cancelled")
        case .speechRecognized(let recognizedString):
//            self.speechTextLabel.text = recognizedString
            print("Recognized String \(recognizedString)")
        case .speechNotRecognized:
            print("Speech Not Recognized")
        case .availabilityChanged(let availability):
            print("Availability \(availability)")
        case .speechRecognitionStopped(let finalRecognizedString):
//            self.speechButton.setTitle("Start speech Recognition", for: .normal)
//            self.speechTextLabel.textColor = .red
//            print("Speech Recognition Stopped with final string \(finalRecognizedString)")
            
            print(finalRecognizedString)
            self.navigateToRelativePage(name: finalRecognizedString)
        }
    }
    
    func navigateToRelativePage(name: String)
    {
        if (name.contains("Balance") || name.contains("Enquirey"))
        {
            self.navigateToBalance()
        }
        else if (name.contains("Transfer") || name.contains("Money"))
        {
            self.navigateToTransfer()
        }
        else if (name.contains("Statement"))
        {
            self.navigateToStatments()
        }
        else if (name.contains("Settings"))
        {
            self.navigateToSettings()
        }
    }
    
    func navigateToBalance()
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "BalanceViewController") as! BalanceViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func navigateToTransfer()
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "TransferViewController") as! TransferViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func navigateToStatments()
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "StatementViewController") as! StatementViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func navigateToSettings()
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SettingsViewController") as! SettingsViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
