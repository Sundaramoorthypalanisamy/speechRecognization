//
//  LoginViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 28/06/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
//    var speechRecognizerUtility: SpeechRecognitionUtility?
    var selectedField: UITextField?
    var sttman: STTManager!

    @IBOutlet weak var container: UIView!
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var forgotButton: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        container.addShadow(color: .darkGray)
        //usernameTextField.addBottomBorderColor(color: UIColor().AppBlue())
        //passwordTextField.addBottomBorderColor(color: UIColor().AppBlue())
        usernameTextField.addLeftView(size: 10)
        passwordTextField.addLeftView(size: 10)
        loginButton.addRoundedCorner()
        
        TTSManager.shared.SpeechContent(message: "Hi, Welcome to Tamil Nesan Mobile Banking app", speedRate: 0.5)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        usernameTextField.text = ""
        passwordTextField.text = ""
        sttman  = STTManager.init()

    }
    
    
    @IBAction func LoginButtonTapped()
    {
        //STTManager.shared.StopSpeechToText()
        self.Login()
    }
    
    func Login()
    {
        if ((self.usernameTextField.text?.count)! < 8)
        {
            self.ShowAlert(message: "Please provide your 8 digit account number")
        }
        else
        {
            let userinfo = DBManager.shared.GetUserInfo(accountnumber: self.usernameTextField.text!)
            if (userinfo?.id == nil){
                self.ShowAlert(message: "Please provide a valid account number")
                return
            }
            else
            {
                if (self.passwordTextField.text == userinfo?.passcode)
                {
                    // Store User Id as Global
                    UserDefaults.standard.set(userinfo?.accountnumber, forKey: "UserAccNum")
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let destinationVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
                    self.navigationController?.pushViewController(destinationVC, animated: true)
                }
                else{
                    self.ShowAlert(message: "Incorrect Passcode")
                }
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func ShowAlert(message: String){
        let alert = UIAlertController(title: UtilsManager.appName, message: message
            , preferredStyle: UIAlertControllerStyle.alert)
        // add the actions (buttons)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.cancel, handler:{ action in }))
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    func GetAccountNumber()
    {
        self.startlistening()
        
//        STTManager.shared.StartSpeechToText(state: .continuous, success: { (success) in
//            //
//            let trimmedString = success.replacingOccurrences(of: " ", with: "")
//            // converted text will comes here
//            let numbers = trimmedString.digits
//            self.usernameTextField.text = trimmedString
//            if (numbers.count == 8){
//                STTManager.shared.StopSpeechToText()
//            }
//        }) { (failedmsg) in
//            //
//        }
        
        //        VTTManager.shared.RecordAndConvertSpeechToText(success: { (response) in
//                    let trimmedString = response.replacingOccurrences(of: " ", with: "")
//                    print(trimmedString)
//                    // converted text will comes here
//                    let numbers = trimmedString.digits
//                    self.usernameTextField.text = trimmedString
//                    if (numbers.count == 8){
//                        VTTManager.shared.StopRecording()
//                    }
        //        }) { (failed) in
        //            //
        //        }
    }
    
    func GetDateofBirth()
    {
        self.startlistening()
        
//        VTTManager.shared.RecordAndConvertSpeechToText(success: { (response) in
//            let trimmedString = response.replacingOccurrences(of: " ", with: "")
//            print(trimmedString)
//            // converted text will comes here
//            let numbers = trimmedString.digits
//            self.passwordTextField.text = numbers
//            if (numbers.count == 8){
//                VTTManager.shared.StopRecording()
//            }
//        }) { (failed) in
//            //
//        }
        
        //        VTTManager.shared.RecordAndConvertSpeechToText(success: { (response) in
        //            let trimmedString = response.replacingOccurrences(of: " ", with: "")
        //            print(trimmedString)
        //            // converted text will comes here
        //            if (trimmedString.count < 8){
        //                self.passwordTextField.text = trimmedString
        //            }else{
        //                self.passwordTextField.text = trimmedString
        //                VTTManager.shared.StopRecording()
        //            }
        //        }) { (failed) in
        //            //
        //        }
    }
    
    func startlistening()
    {
        sttman.StartSpeechToText(state: .continuous, success: { (success) in
            //
            let trimmedString = success.replacingOccurrences(of: " ", with: "")
            // converted text will comes here
            let numbers = trimmedString.digits
            
            self.selectedField?.text = trimmedString
            if (numbers.count == 8){
                self.sttman.StopSpeechToText()
                self.selectedField?.resignFirstResponder()
            }
        }) { (failedmsg) in
            //
        }
    }
}




extension LoginViewController: UITextFieldDelegate{
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textField.text = ""
        sttman.StopSpeechToText()
        return false
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        selectedField = textField
        textField.text = ""
         
        if(textField == self.usernameTextField){
            self.GetAccountNumber()
        }
        else if(textField == self.passwordTextField){
            self.GetDateofBirth()
        }
        textField.resignFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
