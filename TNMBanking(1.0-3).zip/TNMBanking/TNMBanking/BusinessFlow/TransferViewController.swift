//
//  TransferViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 14/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class TransferViewController: UIViewController {
    
    //var speechRecognizerUtility: SpeechRecognitionUtility?
    
    var selectedField: UITextField?
    
    @IBOutlet weak var fromLabel: UILabel!
    @IBOutlet weak var fromTextfield: UITextField!
    @IBOutlet weak var toLabel: UILabel!
    @IBOutlet weak var toTextfield: UITextField!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var amountTextfield: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //self.startListening()
        let useraccno = UserDefaults.standard.value(forKey: "UserAccNum") as! String
        let userinfo = DBManager.shared.GetUserInfo(accountnumber: useraccno)
        
        fromTextfield.text = String(format: "%@", (userinfo?.accountnumber)!)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func GetAccountNumber()
    {
        let sttm = STTManager.init()
        sttm.StartSpeechToText(state: .continuous, success: { (success) in
            //
            let trimmedString = success.replacingOccurrences(of: " ", with: "")
            // converted text will comes here
            let numbers = trimmedString.digits
            
            self.toTextfield.text = trimmedString
            if (numbers.count == 8){
                sttm.StopSpeechToText()
            }
        }) { (failedmsg) in
            //
        }
        
//        VTTManager.shared.RecordAndConvertSpeechToText(success: { (response) in
//            let trimmedString = response.replacingOccurrences(of: " ", with: "")
//            print(trimmedString)
//            // converted text will comes here
//            let numbers = trimmedString.digits
//            self.toTextfield.text = numbers
//            if (numbers.count == 8){
//                VTTManager.shared.StopRecording()
//            }
//        }) { (failed) in
//            //
//        }
    }
    
    
    @IBAction func backButtontapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func transferButtonTapped()
    {
        
        let numbers = self.toTextfield.text?.digits
        guard (numbers?.count)! == 8 else{
            self.ShowAlert(message: "Invalid Account number")
            return
        }
        
        let senderInfo = DBManager.shared.GetUserInfo(accountnumber: self.fromTextfield.text!)
        let receiverInfo = DBManager.shared.GetUserInfo(accountnumber: self.toTextfield.text!)
        if (receiverInfo?.id == nil){
            self.ShowAlert(message: "Please provide a valid account number")
            return
        }
        
        
        guard self.fromTextfield.text! != self.toTextfield.text! else{
            self.ShowAlert(message: "Both account numbers are same ")
            return
        }
        
        
        // Have to update the balance amount in the user table
        let mainBalance = senderInfo?.balance
        let transferAmount = Int(self.amountTextfield.text!)
        if (transferAmount! <= mainBalance!)
        {
            let sender = self.fromTextfield.text! as NSString
            let receiver = self.toTextfield.text! as NSString
            let amount = self.amountTextfield.text! as NSString
            let success = DBManager.shared.TansferFund(from: sender, to: receiver, amount: amount)
            if (success){
                
                let balance = mainBalance! - transferAmount!
                let updated = DBManager.shared.UpdateBalance(userid: (senderInfo?.id)!, amount: balance)
                if (updated){
                    // Have to update the balance amount in the user table
                    TTSManager.shared.SpeechContent(message: "Amount Transferred successfully", speedRate: 0.5)
                    self.ShowAlert(message: "Amount Transferred successfully")

                }
            }
            else{
                // Show the failed messages
                self.ShowAlert(message: "Transfer failed")
            }
        }
        else {
            TTSManager.shared.SpeechContent(message: "Insufficient fund", speedRate: 0.5)
            self.ShowAlert(message: "Your have Insufficient balance to make transfer")
        }
    }
    
    
    func ShowAlert(message: String){
        let alert = UIAlertController(title: UtilsManager.appName, message: message
            , preferredStyle: UIAlertControllerStyle.alert)
        // add the actions (buttons)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.cancel, handler:{ action in }))
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
}



extension TransferViewController: UITextFieldDelegate
{
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textField.text = ""
        VTTManager.shared.StopRecording()
        return false
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        selectedField = textField
        if(textField == self.toTextfield){
            self.GetAccountNumber()
            textField.resignFirstResponder()
        }else{
            //self.startListening()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        selectedField = nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
