//
//  SettingsViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 01/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var accNumTextField: UITextField!
    @IBOutlet weak var accBalTextField: UITextField!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "Settings"
        
        let useraccno = UserDefaults.standard.value(forKey: "UserAccNum") as! String
        let userinfo = DBManager.shared.GetUserInfo(accountnumber: useraccno)
        
        self.nameTextField.text = userinfo?.name
        self.emailTextField.text = userinfo?.email
        self.accNumTextField.text = userinfo?.accountnumber
        self.accBalTextField.text = String(format: "$%d", (userinfo?.balance)!)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func backButtontapped()
    {
        self.navigationController?.popViewController(animated: true)
    }

}
