//
//  ActivityViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 01/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class ActivityViewController: UIViewController {
    
    @IBOutlet weak var bannerImage: UIImageView!

    @IBOutlet weak var submenuContainer: UIView!
    @IBOutlet weak var submenuItem1: UIView!
    @IBOutlet weak var submenuItem2: UIView!
    @IBOutlet weak var submenuItem3: UIView!


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "Activity"
        self.bannerImage.addCornerRadius(radious: 15)
        self.bannerImage.addShadow(color: UIColor.black)

        self.submenuContainer.addCornerRadius(radious: 15)
        self.submenuItem1.addShadow(color: UIColor().AppBlue())
        self.submenuItem2.addShadow(color: UIColor().AppBlue())
        self.submenuItem3.addShadow(color: UIColor().AppBlue())

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func backButtontapped()
    {
        self.navigationController?.popViewController(animated: true)
    }

}
