//
//  StatementViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 19/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class StatementViewController: UIViewController {
    
    @IBOutlet weak var statementTableview: UITableView!
    
    var transactions: NSMutableArray!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let useraccno = UserDefaults.standard.value(forKey: "UserAccNum") as! NSString
        transactions = DBManager.shared.GetTransactionsFor(accnumber: useraccno) as! NSMutableArray
        
        statementTableview.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButtontapped()
    {
        self.navigationController?.popViewController(animated: true)
    }
    

}

extension StatementViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
        //return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:StatementCell = tableView.dequeueReusableCell(withIdentifier: "StatementCell", for: indexPath) as! StatementCell
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.separatorInset = UIEdgeInsets.zero;
        
        let myaccnum = UserDefaults.standard.value(forKey: "UserAccNum") as! NSString
        let transaction = self.transactions[indexPath.row] as! Statement

        if (transaction.from == myaccnum as String){
            // I received
            cell.lblName.text = transaction.to
            cell.lblDate.text = transaction.date
            cell.lblAmount.text = transaction.amount
            cell.lblAmount.textColor = UIColor.red
        }else{
            // I sent
            cell.lblName.text = transaction.from
            cell.lblDate.text = transaction.date
            cell.lblAmount.text = transaction.amount
            cell.lblAmount.textColor = UIColor.green
        }
        
//        let item = self.listItems[indexPath.row] as! NSDictionary
//        cell.lblTitle.text = item.value(forKey: "title") as? String
//        cell.lblDesc.text = item.value(forKey: "desc") as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //
       
    }
}


class StatementCell: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblDate: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}


