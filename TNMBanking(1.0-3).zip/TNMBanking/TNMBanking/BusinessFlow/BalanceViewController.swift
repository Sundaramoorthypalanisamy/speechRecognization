//
//  BalanceViewController.swift
//  TNMBanking
//
//  Created by Prabakaran on 14/07/18.
//  Copyright © 2018 MyMin Solutions. All rights reserved.
//

import UIKit

class BalanceViewController: UIViewController {

    @IBOutlet weak var balanceLabel: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let useraccno = UserDefaults.standard.value(forKey: "UserAccNum") as! String
        let userinfo = DBManager.shared.GetUserInfo(accountnumber: useraccno)
        let balance = userinfo?.balance
        self.balanceLabel.text = "$ \(balance!)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func backButtontapped()
    {
        self.navigationController?.popViewController(animated: true)
    }

}
